# Handoff: Refonte modale d'accueil "MaClasse"

## Overview
Refonte de la modale d'accueil de l'application "MaClasse" (choix entre créer une classe ou charger une sauvegarde). L'objectif : agrandir la modale en mode PC/desktop, réorganiser le contenu en cartes bien séparées, garder le titre et le message d'erreur en haut sur toute la largeur, et ajouter une troisième carte pour l'accès au référentiel de compétences.

## About the Design Files
Le fichier fourni (`MaClasse Accueil.dc.html`) est une **référence de design créée en HTML** — un prototype montrant l'apparence et le comportement attendus, ce n'est pas du code de production à copier tel quel. La tâche consiste à **recréer ce design dans l'environnement existant du projet** (framework/librairies déjà en place dans le code de l'application "MaClasse"), en respectant ses patterns établis (composants, gestion d'état, styles) — pas à intégrer le HTML directement.

## Fidelity
**High-fidelity (hifi)** : couleurs, typographie, espacements et structure de layout sont définitifs. Le développeur doit recréer l'UI fidèlement avec les composants/styles déjà utilisés dans le codebase (bouton, input, carte, etc.), en réutilisant si possible les composants existants plutôt qu'en créant un nouveau design system.

## Screens / Views

### Modale d'accueil "MaClasse"
**Purpose**: Point d'entrée de l'application — l'utilisateur choisit de créer une nouvelle classe à partir d'un jeu de données d'exemple, de charger la dernière sauvegarde de sa classe (fichier ZIP + mot de passe), ou d'accéder au référentiel de compétences.

**Layout**
- Modale centrée verticalement et horizontalement dans le viewport, fond de page gris foncé (`#5b5f5a`) derrière.
- Largeur : responsive, `max-width` **980px** en desktop (contre ~470px avant refonte) ; `width: 100%` avec marges sur petit écran.
- Fond blanc, `border-radius: 10px`, `box-shadow: 0 20px 50px rgba(0,0,0,0.35)`.
- Deux zones empilées verticalement :
  1. **En-tête** (titre + message de bienvenue + erreur éventuelle) — pleine largeur, séparé du contenu par une bordure basse `1px solid #e3e8e4`. Padding `28px 32px 20px 32px`.
  2. **Zone des cartes** — grille de **3 colonnes égales** en desktop (`grid-template-columns: repeat(3, 1fr)`), `gap: 20px`, padding `28px 32px 32px 32px`. Sur mobile/tablette étroite, passer en 1 colonne empilée.

**Components**

1. **Titre** — `<h1>` "MaClasse", `font-size: 22px`, `font-weight: 700`, couleur `#1c6b32`.
2. **Message de bienvenue** — texte "Bienvenue dans MaClasse — gérez votre classe, à votre façon.", `font-size: 15px`, `font-weight: 500`, couleur `#2f8f4e`.
3. **Bandeau d'erreur** (conditionnel, affiché seulement si une erreur survient) — texte "Fichier invalide ou corrompu.", fond `#fbe4e4`, bordure `1px solid #f2b9b9`, texte couleur `#b23b3b`, `font-weight: 600`, `font-size: 14px`, `padding: 12px 16px`, `border-radius: 6px`, marge du dessus `16px`. **Reste dans l'en-tête, pleine largeur**, jamais dans une carte.

4. **Carte "Nouveau"**
   - Bordure `1px solid #d7e4da`, `border-radius: 10px`, fond `#fbfdfb`, padding `22px 20px`, `display: flex; flex-direction: column; gap: 14px`.
   - Titre carte : "Première utilisation ?" — `16px / 700 / #1c6b32`.
   - Texte : "Créez votre espace de classe à partir d'un jeu de données d'exemple." — `14px / #3d4a3f`.
   - Bouton (poussé en bas de carte via un spacer flex) : "Créer ma classe à partir d'un jeu de données d'exemple" — fond `#1e8a3c`, texte blanc, `font-weight: 700`, `font-size: 14.5px`, `border-radius: 6px`, `padding: 14px 16px`, hover → `#186f30`.

5. **Carte "Charger"**
   - Même style de carte que ci-dessus.
   - Titre carte : "Sélectionner la dernière version des données de votre classe" — `16px / 700 / #1c6b32`.
   - Champ **Fichier ZIP** : label `13px / 700 / #1c6b32`, conteneur avec bordure `1px solid #bfe3c9`, `border-radius: 6px`, contient un bouton "Choisir un fichier" (style natif input file) + nom du fichier sélectionné (`#6b6b6b` si vide "Aucun fichier choisi", `#1c6b32` si un fichier est choisi).
   - Champ **Mot de passe** : label `13px / 700 / #1c6b32`, input type password, bordure `1px solid #bfe3c9`, `border-radius: 6px`, `padding: 10px 12px`.
   - Bouton "Charger" : fond vert clair `#8fc99d` **désactivé visuellement** tant que le mot de passe est vide, devient `#1e8a3c` (vert plein) dès qu'un mot de passe est saisi. Texte blanc, `font-weight: 700`, pleine largeur de la carte, poussé en bas.

6. **Carte "Référentiel" (NOUVELLE)**
   - Même style de carte que les deux autres (bordure, fond, padding, radius identiques — cohérence visuelle).
   - Titre carte : "Référentiel de compétences" — `16px / 700 / #1c6b32`.
   - Texte : "L'application contient un référentiel des compétences issues des BO de l'EN." — `14px / #3d4a3f`.
   - Bouton "Accéder aux programmes" : style **outline** (pas plein comme les deux autres), fond blanc, bordure `2px solid #1e8a3c`, texte `#1e8a3c`, `font-weight: 700`, hover → fond `#eefaf1`. Poussé en bas de carte.

## Interactions & Behavior
- Saisie du mot de passe → active/désactive visuellement le bouton "Charger" (couleur du bouton change ; la logique de soumission réelle — appel API, validation fichier — est à implémenter côté application, ce prototype ne fait que illustrer l'état visuel).
- Sélection d'un fichier ZIP → le nom du fichier remplace "Aucun fichier choisi" dans le champ.
- Message d'erreur "Fichier invalide ou corrompu." → apparaît dans l'en-tête (pleine largeur, sous le message de bienvenue) quand le chargement échoue côté backend. Ne déplace pas le titre.
- Boutons "Créer ma classe...", "Charger", "Accéder aux programmes" : actions de navigation/soumission à connecter à la logique métier existante de l'application.
- Responsive : en dessous d'une largeur d'écran mobile/tablette, les 3 cartes doivent repasser en 1 colonne empilée (grid-template-columns: 1fr), la modale prenant ~100% de la largeur disponible avec marges.

## State Management
- `password` (string) : valeur du champ mot de passe, contrôle l'état visuel du bouton "Charger".
- `fileName` (string | null) : nom du fichier ZIP sélectionné.
- `errorMessage` (string | null) : message d'erreur à afficher dans l'en-tête, `null` = pas d'erreur affichée.
- Ces états sont probablement déjà gérés par la logique existante de l'application ; seul le layout/style change.

## Design Tokens
**Couleurs**
- Vert principal (titres, texte de marque) : `#1c6b32`
- Vert bouton plein : `#1e8a3c` (hover `#186f30`)
- Vert bouton désactivé/clair : `#8fc99d`
- Vert texte secondaire (bienvenue) : `#2f8f4e`
- Bordure carte / input : `#d7e4da` (carte), `#bfe3c9` (input)
- Fond carte : `#fbfdfb`
- Fond page derrière modale : `#5b5f5a`
- Erreur — fond : `#fbe4e4`, bordure : `#f2b9b9`, texte : `#b23b3b`
- Texte corps carte : `#3d4a3f`
- Texte placeholder fichier vide : `#6b6b6b`

**Typographie** : police système (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`).
- Titre modale : 22px / 700
- Titres de carte : 16px / 700
- Corps de texte : 14–15px / 400–500
- Boutons : 14.5px / 700
- Labels de champ : 13px / 700

**Espacements / rayons**
- Modale : `border-radius: 10px`, `box-shadow: 0 20px 50px rgba(0,0,0,0.35)`
- Cartes et inputs : `border-radius: 6–10px`
- Gap entre cartes : `20px`
- Padding en-tête : `28px 32px 20px 32px`
- Padding zone cartes : `28px 32px 32px 32px`
- Padding interne carte : `22px 20px`

## Assets
Aucun asset externe (image/icône) — design 100% typographique et formes CSS simples.

## Files
- `MaClasse Accueil.dc.html` — prototype HTML de référence (fichier "Design Component" streamable, à ne pas copier tel quel — voir section "About the Design Files").
